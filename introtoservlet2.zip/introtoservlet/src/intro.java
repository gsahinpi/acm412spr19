

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class intro
 */
@WebServlet("/ali")
public class intro extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public intro() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		java.sql.Date d=new java.sql.Date(0, 0, 0);
		String url="jdbc:mysql://localhost/";
		String db="feedback";
		String user="sqluser";
		String pass="sqluserpw";
		String tablename="comments";
		dbUtility dummy=new dbUtility(url,db,tablename,user,pass);
		
		if (request.getParameter("deletebutton")!=null)
		{
			String id=request.getParameter("param1");
			System.out.println("will delete param1:"+id);
			int input=Integer.parseInt(id);
			dummy.deleteitem(input);
		}
		
		
		
		ArrayList <dbrepresent>data=dummy.listalltable();
	
		
		
		//dbrepresent dummy=new dbrepresent(1,"den","den2",
			//	"den3", d,"den4","den5");
		//data.add(dummy);
		   
		
		String output="<html>";
			output+="<body >";
			output+="<h1>Hellloo people<h1>";
			
			output+="<table border=\"1\">";
			output+="<tr><th>id</th>"
					+ "<th>user</th>"
					+ "<th>email</th> "
					+ "<th>webpage</th>"
					+ "<th>datum</th>"
					+ "<th>Summary</th>"
					+ "<th>Comments</th></tr>";
			
			for (int  i=0;i<data.size();i++)
			{
				output+="<tr>";
				
			
				output+="<td>"+data.get(i).getId()+"</td>";
				output+="<td>"+data.get(i).getMYUSER()+"</td>";
				output+="<td>"+data.get(i).getEMAIL()+"</td>";
				output+="<td>"+data.get(i).getWEBPAGE()+"</td>";
				output+="<td>"+data.get(i).getDATUM()+"</td>";
				output+="<td>"+data.get(i).getSUMMARY()+"</td>";
				output+="<td>"+data.get(i).getCOMMENTS()+"</td>";
			
				output+="</tr>";
			}//for int i
			
			output+="</table>";
			
			
			output+="<FORM ACTION=\"ali\">"+
					  "id to delete:  <INPUT TYPE=\"TEXT\" NAME=\"param1\">"
					  +"<INPUT  TYPE=\"SUBMIT\" NAME=\"deletebutton\">"+"	</FORM>";
            output+="<a href=\"http://localhost:8080/introtoservlet/insert.html\">"
            		+ "insert new item</a>";
			output+="</body>";
			output+="</html>";
			
			
	
			response.getWriter().append(output);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
