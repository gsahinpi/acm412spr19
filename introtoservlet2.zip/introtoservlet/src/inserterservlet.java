

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class inserterservlet
 */
@WebServlet("/inserterservlet")
public class inserterservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public inserterservlet() {
        super();
        // TODO Auto-generated constructor stub
       
		
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String in1=request.getParameter("in1");
		String in2=request.getParameter("in2");
		String in3=request.getParameter("in3");
		String in4=request.getParameter("in4");
		String in5=request.getParameter("in5");
		System.out.println(in1+" "+in2+" "+in3+" "+in4+" "+in5);
		 java.sql.Date d=new java.sql.Date(0, 0, 0);
			String url="jdbc:mysql://localhost/";
			String db="feedback";
			String user="sqluser";
			String pass="sqluserpw";
			String tablename="comments";
			dbUtility dummy=new dbUtility(url,db,tablename,user,pass);
			dummy.insertunique(in1,in2,in3,d,in4,in5);
			response.sendRedirect("ali");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
