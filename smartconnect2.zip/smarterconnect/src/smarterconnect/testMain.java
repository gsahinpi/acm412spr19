package smarterconnect;

import java.util.ArrayList;

public class testMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url="jdbc:mysql://localhost/";
		String db="feedback";
		String user="sqluser";
		String pass="sqluserpw";
		String tablename="comments";
		dbUtility dummy=new dbUtility(url,db,tablename,user,pass);
		ArrayList <dbrepresent> returned=dummy.listalltable();
		printlist(returned);
		//dummy.insertitem("veli", "veli@x.com", "www.x.com", new  java.sql.Date(2019, 25, 02), "yorum yok", "cemre havaya,suya,toprak");
		returned=dummy.listalltable();
		printlist(returned);
		System.out.println(dummy.isNameIn("veli"));
		
		System.out.println(dummy.isNameIn("sssssss"));
		dummy.insertunique("sssss", "veli@x.com", "www.x.com", new  java.sql.Date(2019, 25, 02), "yorum yok", "cemre havaya,suya,toprak");
		dummy.insertunique("ssss", "veli@x.com", "www.x.com", new  java.sql.Date(2019, 25, 02), "yorum yok", "cemre havaya,suya,toprak");
		dummy.insertunique("eli", "veli@x.com", "www.x.com", new  java.sql.Date(2019, 25, 02), "yorum yok", "cemre havaya,suya,toprak");
		dummy.insertunique("eli", "veli@x.com", "www.x.com", new  java.sql.Date(2019, 25, 02), "yorum yok", "cemre havaya,suya,toprak");
		 
		returned=dummy.listalltable();
		printlist(returned);
	}
	public static  void printlist(ArrayList<dbrepresent> l)
	{
	 for (dbrepresent d:l)
	 {
		 System.out.println(d.getId()+" "+d.MYUSER+" "+d.EMAIL+" "+d.COMMENTS);
	 }
		
	}

}
