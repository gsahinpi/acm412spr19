package smarterconnect;

import java.sql.Date;

public class dbrepresent {
	int id;
	String MYUSER;
	String EMAIL;
	String WEBPAGE;
	Date DATUM;
	String COMMENTS;
	String SUMMARY;
	public dbrepresent(int id, String mYUSER, String eMAIL, String wEBPAGE, Date dATUM, String cOMMENTS,
			String sUMMARY) {
		super();
		this.id = id;
		MYUSER = mYUSER;
		EMAIL = eMAIL;
		WEBPAGE = wEBPAGE;
		DATUM = dATUM;
		COMMENTS = cOMMENTS;
		SUMMARY = sUMMARY;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMYUSER() {
		return MYUSER;
	}
	public void setMYUSER(String mYUSER) {
		MYUSER = mYUSER;
	}
	public String getEMAIL() {
		return EMAIL;
	}
	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}
	public String getWEBPAGE() {
		return WEBPAGE;
	}
	public void setWEBPAGE(String wEBPAGE) {
		WEBPAGE = wEBPAGE;
	}
	public Date getDATUM() {
		return DATUM;
	}
	public void setDATUM(Date dATUM) {
		DATUM = dATUM;
	}
	public String getCOMMENTS() {
		return COMMENTS;
	}
	public void setCOMMENTS(String cOMMENTS) {
		COMMENTS = cOMMENTS;
	}
	public String getSUMMARY() {
		return SUMMARY;
	}
	public void setSUMMARY(String sUMMARY) {
		SUMMARY = sUMMARY;
	}
	
	

}
