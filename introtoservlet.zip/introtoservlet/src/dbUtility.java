

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class dbUtility {
	String url;
	String dbname;
	String tablename;
	String username;
	String password;
	 Connection connect;
	public dbUtility(String url, String dbname, String tablename, String username, String password) {
		super();
		this.url = url;
		this.dbname = dbname;
		this.tablename = tablename;
		this.username = username;
		this.password = password;
		try {
		connect=	DriverManager
			.getConnection(url+dbname+"?"
			        + "user="+username+"&password="+password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}//constructor
	
	public ArrayList <dbrepresent> listalltable()
	{
		ArrayList <dbrepresent> myresults=new ArrayList <dbrepresent>();
		   PreparedStatement preparedStatement;
		try {
			
			
			 Statement statement = connect.createStatement();
			ResultSet resultSet = statement
			            .executeQuery("select * from feedback.comments");
			 
			 
			 while (resultSet.next()) {
		            // It is possible to get the columns via name
		            // also possible to get the columns via the column number
		            // which starts at 1
		            // e.g. resultSet.getSTring(2);
				   int i=resultSet.getInt("id");
		            String user = resultSet.getString("myuser");
		            String website = resultSet.getString("webpage");
		            String em=resultSet.getString("email");
		            String summary = resultSet.getString("summary");
		            Date date = resultSet.getDate("datum");
		            String comment = resultSet.getString("comments");
		            dbrepresent dbpoint=new dbrepresent(i,user,em,website,date,comment,summary);
		            myresults.add(dbpoint);
		            
		        }
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
          
		
		
				
		
		   return myresults;
		
	}
	
	public void insertitem(String MYUSER,String EMAIL,String WEBPAGE,Date DATUM,
			String COMMENTS,String SUMMARY)
	{
		 try {
			PreparedStatement preparedStatement = connect
	.prepareStatement("insert into  feedback.comments values (default, ?, ?, ?, ? , ?, ?)");
		
			 preparedStatement.setString(1, MYUSER);
	            preparedStatement.setString(2, EMAIL);
	            preparedStatement.setString(3, WEBPAGE);
	            preparedStatement.setDate(4, DATUM);
	            preparedStatement.setString(5, COMMENTS);
	            preparedStatement.setString(6, SUMMARY);
	            preparedStatement.executeUpdate();

		 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}//insertitem
	public boolean isNameIn(String name)
	{
		String query="SELECT * FROM `comments` WHERE MYUSER=?";
		 try {
		PreparedStatement ps = connect.prepareStatement(query);
	   
			ps.setString(1, name);
			  ResultSet rs = ps.executeQuery();
			  int i = 0;
			  while(rs.next()) {
			      i++;
			      return true;
			  }
			  return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    // process the results
	  
		return false;
		
	}//isname
	public void insertunique(String MYUSER,String EMAIL,String WEBPAGE,Date DATUM,
			String COMMENTS,String SUMMARY)
	{
		if (!isNameIn(MYUSER))
		{
			System.out.println("******"+MYUSER);
			insertitem(MYUSER, EMAIL, WEBPAGE, DATUM, COMMENTS, SUMMARY);
		}
		else
		{
			System.out.println("!!!!"+MYUSER);
		}
	}

}//class
